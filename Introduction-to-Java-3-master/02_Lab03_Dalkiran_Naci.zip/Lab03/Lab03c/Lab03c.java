/*
 * The program prompts the user for an integer and then rolls a die three times.
 * The program randomly generates 3 integers between 1 and 6.
 * Your program outputs the number of rolls that are smaller than, equal to
 * and greater than the user's input.
 * @author Muhammed Naci Dalk�ran
 * @date   27.02.2018
 */
import java.util.Scanner;
public class Lab03c
{
  public static void main( String[] args )
  {
    Scanner scan = new Scanner( System.in );
    
    //Variable
    int firstRoll;
    int secondRoll;
    int thirdRoll;
    int usersNumber;
    int equalNumbers;
    int greeterNumbers;
    int smallerNumbers;
    
    //Program Code
    firstRoll = (int)( Math.random() * 6) + 1  ;
    secondRoll = (int)( Math.random() * 6) + 1  ;
    thirdRoll = (int)( Math.random() * 6) + 1 ;
    
    equalNumbers = 0;
    greeterNumbers = 0;
    smallerNumbers = 0;
    
    //Input from users
    System.out.println( "Please enter an integer between 1 - 6 " );
    usersNumber = scan.nextInt();
    
    //Conditions
    if ( usersNumber >= 1 && usersNumber <= 6 )
    {
      System.out.println( "first roll = " + firstRoll + ", second roll = " + secondRoll + ", third roll = " + thirdRoll );
      
      //For firstRoll
      if ( firstRoll == usersNumber )
      {
        equalNumbers++;
      }
      else if ( firstRoll > usersNumber )
      {
        greeterNumbers++;
      }
      else if ( firstRoll < usersNumber )
      {
        smallerNumbers++;
      }
      
      //For secondRoll
      if ( secondRoll == usersNumber )
      {
        equalNumbers++;
      }
      else if ( secondRoll > usersNumber )
      {
        greeterNumbers++; 
      }
      else if ( secondRoll < usersNumber )
      {
        smallerNumbers++;
      }
      
      //For thirdRoll 
      if ( thirdRoll == usersNumber )
      {
        equalNumbers++;
      }
      else if ( thirdRoll > usersNumber )
      {
        greeterNumbers++;
      }
      else if ( thirdRoll < usersNumber )
      {
        smallerNumbers++;
      }
      //User Screen
      System.out.println( "# of rolls smaller: " + smallerNumbers );
      System.out.println( "# of rolls equal: " + equalNumbers );
      System.out.println( "# of rolls greater: " + greeterNumbers );
      
    }
    // If user input a different number not between 6 and 1
    else     
    {
      System.out.println( "It should be between 6 and 1" );    
    }
  }
}
