/*
 * The program is a kind of vending machine program.
 * There are three drink types in the machine.
 * Each drink has a product number and price
 * The program input data from users.
 * The program  prompt the user to enter a product number.
 * It should then output the price of the selected drink and prompt the user to
 * enter the payment amount.
 * The program will then output to the user the amount of change.
 * @author Muhammed Naci Dalk�ran
 * @date   27.02.2018
 */

import java.util.Scanner;

public class Lab03b
{
   public static void main( String[] args )
   {
      
      //Constrant
      final int WATER = 1;
      final int ORANGE_JUICE = 2;
      final int MILK = 3;
      final int WATER_PRICE = 50;
      final int ORANGE_JUICE_PRICE = 100;
      final int MILK_PRICE = 150;
      
      //variable
      double paymentAmount;
      int choice;
      int change;
      
      //Program Code
      Scanner scan = new Scanner( System.in );
      
      System.out.println( "Drink options:" );
      System.out.println( "(1) Water" );
      System.out.println( "(2) Orange Juice" );
      System.out.println( "(3) Milk" );
      System.out.print( "Please enter your choice : " );
      
      //check the input
      if ( !scan.hasNextInt() ) 
      {
         System.out.println( "Invalid payment amount, you must enter integer" );
      }
      
      else 
      {
         choice = scan.nextInt();
         
         if ( choice == WATER )
         {
            System.out.println( "Water price = " + WATER_PRICE + " unit " );
            System.out.print( "Please enter your payment" );
            
            //check the input
            if ( !scan.hasNextInt() ) 
            { 
               System.out.println( "Invalid payment amount, you must enter integer" );
            } 
            else 
            {       
               paymentAmount = scan.nextDouble(); 
               
               //process of change
               if( (int) paymentAmount >= WATER_PRICE )
               {
                  change = (int) paymentAmount - WATER_PRICE;
                  if( paymentAmount == (int) paymentAmount )
                  {
                     System.out.println( "Thank you for your order. Your change is: " + change );
                  }
                  else
                  {
                     System.out.println( "Invalid payment amount, you must enter integer" );
                  }
               }
               else 
               {
                  System.out.println( "Payment amount is not sufficent!" );
               }
            }
         }
         
         else if ( choice == ORANGE_JUICE )
         {
            System.out.println( "Orange juice price = " + ORANGE_JUICE_PRICE + " unit" );
            System.out.print( "Please enter your payment" );
            
            //check the input
            if ( !scan.hasNextInt() ) 
            { 
               System.out.println( "Invalid payment amount, you must enter integer" );
            } 
            else 
            {       
               paymentAmount = scan.nextDouble(); 
               
               //process of change
               if( (int) paymentAmount >= ORANGE_JUICE_PRICE )
               {
                  change = (int) paymentAmount - ORANGE_JUICE_PRICE;
                  
                  if( paymentAmount == (int) paymentAmount )
                  {
                     System.out.println( "Thank you for your order. Your change is: " + change );
                  }
                  else
                  {
                     System.out.println( "Invalid payment amount, you must enter integer" );
                  }
               }
               else 
               {
                  System.out.println( "Payment amount is not sufficent!" );
               }
            }
         }
         else  if ( choice == MILK)
         {
            System.out.println( "Orange juice price = " + ORANGE_JUICE_PRICE + " unit" );
            System.out.print( "Please enter your payment" );
            
            //check the input
            if ( !scan.hasNextInt() ) 
            { 
               System.out.println( "Invalid payment amount, you must enter integer" );
            } 
            else 
            {       
               paymentAmount = scan.nextDouble(); 
               
               //process of change
               if( (int) paymentAmount >= MILK_PRICE )
               {
                  change = (int) paymentAmount - MILK_PRICE;
                  
                  if( paymentAmount == (int) paymentAmount )
                  {
                     System.out.println( "Thank you for your order. Your change is: " + change );
                  }
                  else
                  {
                     System.out.println( "Invalid payment amount, you must enter integer" );
                  }
               }
               else 
               {
                  System.out.println( "Payment amount is not sufficent!" );
               }
            }
         }
         else if ( choice > 3 )
         {
            System.out.println( "This option is invalid!!" );
         }
      }
   }  
}