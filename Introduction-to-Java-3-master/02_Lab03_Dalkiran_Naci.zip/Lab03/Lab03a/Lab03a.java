/*
 * The program inputs the necessary data from users.
 * The program  allows users to research for a menu item.
 * Then, the program displays the correct menu item.
 * 
 * @author Muhammed Naci Dalk�ran
 * @date   27.02.2018
 */
import java.util.Scanner;

public class Lab03a
{
  public static void main( String[] args )
  {
    Scanner scan = new Scanner( System.in );
    
    //Variable
    int secondChoice;
    String firstChoice;
    
    //Program Code
    System.out.print( "Find (m)ain course or (d)essert" );
    firstChoice = scan.next();
    
    //Conditions
    if ( firstChoice.equals( "m" ) )
    {
      System.out.println( "Does it have meat? ( 1-Yes / 2-No )" );
      secondChoice = scan.nextInt();
      
      if ( secondChoice == 1)
      {
        System.out.println( "Sorry - vegetarian options only" );
      }
      
      else if ( secondChoice == 2 )
      {
        System.out.println( "You are searching for Four Cheese Pizza!" );
      }
      
      else 
      {
        System.out.println( "Sorry, no matching menu items..." );
      }
      
    }
    else if (firstChoice.equals( "d" ) )
    {
      System.out.println( "Does it contain apples? ( 1 - Yes / 2 - No )" );
      secondChoice = scan.nextInt();
      
      if( secondChoice == 1 )
      {
        System.out.println( "You are searching for Apple Pie!" );
      }
      
      else if( secondChoice == 2 )
      {
        System.out.println("Your are searching for Creme Brulee!" ); 
      }
      else
      {
        System.out.println( "Sorry, no matching menu items..." );
      }
    }
    else 
    {
      System.out.println( "Sorry, no matching menu items..." );
    }
  }
  
}




