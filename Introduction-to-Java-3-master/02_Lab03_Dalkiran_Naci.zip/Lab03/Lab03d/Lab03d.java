/*
 * The program inputs three names from users.
 * The program  reads in three names and sorts them in alphabetical order. 
 * There are 6 options.
 * The program compare all options and show the alphabetical order. 
 * 
 * @author Muhammed Naci Dalk�ran
 * @date   27.02.2018
 */


import java.util.Scanner;

public class Lab03d
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      
      //Variable
      String firstName;
      String secondName;
      String thirdName;
      String temp;
      int firstCompare;
      int secondCompare;
      int thirdCompare;
      
      //Program Code
      
      //Input from users
      System.out.println( "Please enter three names:" );
      
      firstName = scan.next();
      secondName = scan.next();
      thirdName = scan.next();
      
      //First Compare between first name and second name
      if ( firstName.compareToIgnoreCase(secondName) > 0 )
      { 
         temp = firstName;
         firstName = secondName;
         secondName = temp;  
      }
      //Second Compare between first name and third name
      if ( firstName.compareToIgnoreCase(thirdName) > 0 )
      {  
         temp = firstName;
         firstName = thirdName;
         thirdName = temp;         
      }  
      //Third Compare between second and third name
      if ( secondName.compareToIgnoreCase(thirdName) > 0 )
      {
         temp = secondName;
         secondName = thirdName;
         thirdName = temp;   
      }
      //User Screen
      System.out.println( firstName + "\n" +  secondName + "\n" +  thirdName ) ;
   }
} 










