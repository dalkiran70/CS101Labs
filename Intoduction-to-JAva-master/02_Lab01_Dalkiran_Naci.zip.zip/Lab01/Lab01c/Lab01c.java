 /*
 * Firstly, The program want to some values from users.
 * These values are waist measurement and hip measurement as cm.
 * As using users values, the programe calculates the waist hip ratio (waist measurement/hip measurement) and display the result.
 * 
 * Explanation:One of the indicators of heart disease risk is the waist/hip ratio.
 * For women, a waist hip ratio above 0.8 put you at increased risk.
 * For men a waist hip ratio above 0.9 indicates an increased risk.
 * 
 * 
 * @author Muhammed naci dalk�ran
 * @date   13.02.2018
 */
import java.util.Scanner;
public class Lab01c
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in ); 
      
      //Variables
      int hip;
      int waist;
      double whr;
      
     //Program Code
      System.out.println( "Please write your waist :" );
      waist = scan.nextInt(); // inputing waist measurement
      
      System.out.println( "Please write your hip :" );
      hip = scan.nextInt(); // inputing hip measurement
      
      whr = (double) waist / hip ;
      System.out.println( "WHR: " + whr ); //(waist measurement/hip measurement) ration 
   }
}