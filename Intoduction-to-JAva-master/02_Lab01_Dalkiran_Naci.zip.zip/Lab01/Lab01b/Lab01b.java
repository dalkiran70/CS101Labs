 /*
 * It is a Java program calculating the total profit for a restaurant in a given month. 
 * There are some expenditures, namely staff Cost, food Cost, and overhead.
 * To calculate total profit,the program operates that gross sales minus all expenditures(staff cost, food cost overhead)
 * Then, the program calculates total profit.
 * 
 * @author Muhammed naci dalk�ran
 * @date   13.02.2018
 */

public class Lab01b
{
   public static void main( String[] args )
   {
      // Constants
      final double STAFF_COST_PERCENT = 0.28;
      final double FOOD_COST_PERCENT = 0.3;
      final double OVERHEAD_PERCENT = 0.12;

      //Variables
      int grossSales;
      int staffCost;
      int foodCost;
      int overhead;
      int profit;
    
      //Program Code
      grossSales = 475260;
      staffCost = ( int ) ( grossSales * STAFF_COST_PERCENT ) ;
      foodCost = ( int ) ( grossSales * FOOD_COST_PERCENT ) ;
      overhead = ( int ) ( grossSales * OVERHEAD_PERCENT ) ;
      profit =  ( int ) ( grossSales - ( staffCost + foodCost + overhead ));
      
      
      System.out.println( "GROSS SALES: \t" + grossSales + "TL" );
      System.out.println( "**************************" );
      System.out.println( "FOOD COST: \t" + "0.3\t" + foodCost );
      System.out.println( "STAFF COST: \t" + "0.28\t" + staffCost );
      System.out.println( "OVERHEAD:  \t" + "0.12 \t" + overhead );
      System.out.println( "**************************" );
      System.out.println( "PROFIT:\t" + profit + "TL" );
      
      
   }
}