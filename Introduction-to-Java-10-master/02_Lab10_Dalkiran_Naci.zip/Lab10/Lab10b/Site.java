/*
 * the class including sites.
 * Actually, this class creates a houses for sites.
 * Also,  there are some method and these methods are for
 * adding house, calculating total residents, and view House.
 * And also, it want to �nput from users acoording to methods.
 * @author Muhammed Naci Dalk�ran
 * @date   24.04.2018
 */
import java.util.Scanner;
import java.util.ArrayList;
public class Site
{
   //Constant
   private final int MAX_HOUSES = 10;
   private final String LINE = "-----------------------";
   
   //Variable
   private Hause[] hauseList;
   private int houseCount;
   private String siteName;
   private int residents;
   
   /**
    * This method is Constructor method.
    * @param siteName is name of site.
    */
   public Site( String siteName )
   {
      hauseList = new Hause[MAX_HOUSES];
      this.siteName = siteName;
      houseCount = -1;
      
   }
   /**
    * This method is boolean method.
    * @return boolean,which is for empty house and whole house.
    */
   public boolean addHouse()
   {
      Scanner scan = new Scanner(System.in);
      //Variable
      String ownerName, address;
      int resident;
      double serviceChargePerResident;
      Hause newHouse;  
      //Program Code
      
      houseCount += 1;
      System.out.print( "Enter Owner Name : " );
      ownerName = scan.next();
      System.out.print( "Enter Address: " );
      address = scan.next();
      System.out.print( "Enter number of residents: " );
      residents = scan.nextInt();
      System.out.print( "Enter service charge : " );
      serviceChargePerResident = scan.nextDouble();
      
      newHouse = new Hause(ownerName, address, residents, serviceChargePerResident);
      
      if ( houseCount <= MAX_HOUSES )
      {
         hauseList[houseCount] = newHouse;
         updateTotalResidents(residents);
         return true;
      }
      else
      {
         return false;
      }  
   }
   /**
    * This method is calculating a total resident.
    * @param residents is number of resident in house
    */
   public void updateTotalResidents(int residents)
   {
      this.residents += residents;       
   }
   /**
    * This method is showing a whole house not being empty.  
    */
   public void wievHouses()
   {
      System.out.println( "List of House in " + siteName );
      System.out.println( LINE );
      for ( int i = 0; i <= houseCount; i++)
      {
         System.out.println( "\n" + hauseList[i].toString());
      }
      System.out.println ("Total residents on Site: " + residents);
   }
   /**
    * This method is showing a whole house not being empty.  
    * @param min is minumum value for service fee
    * @param max is maximum value for service fee
    * @return houses, returning houses.
    */
   public ArrayList<Hause> searchHouseByFee(double min, double max)
   {
      ArrayList<Hause> houses = new ArrayList<Hause>();
      for ( int i = 0; i <= houseCount; i++)
      {
         if ( min < hauseList[i].calculateTotalServiceFee() && hauseList[i].calculateTotalServiceFee() < max)
            houses.add(hauseList[i]);
      }
      return houses; 
   }
}



