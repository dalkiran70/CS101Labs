/*
 * the class including house.
 * Actually, this class creates a houses.
 * Also,  there are some method and these methods are for
 * calculating total mountly amount of fee money, and showing house information.
 * @author Muhammed Naci Dalk�ran
 * @date   24.04.2018
 */
public class Hause
{
   //Proporties
   //Variable
   private String ownerName;
   private String address;
   private int residents;
   private double serviceChargePerResident;
   
   /**
    * This method is Constructor method.
    * @param ownerName is neme of owner, who has house.
    * @param address is adres of house.
    * @param residents how many people is living house.
    * @param serviceChargePerResident how much money need for per resident.
    */
   public Hause(String ownerName, String address, int residents, double serviceChargePerResident )
   {
      this.setOwnerName( ownerName );
      this.setAddress( address );
      this.setResidents( residents );
      this.setServiceChargePerResident( serviceChargePerResident );
      
   }
   /**
    * This method is getting owner name
    * @return ownerName is a name of owner.
    */
   public String getOwnerName()
   {
      return ownerName;
   }
   /**
    * This method is getting address
    * @return address is a name of address.
    */
    public String getAddress()
   {
      return address;
   }
    /**
    * This method is getting residents
    * @return residents is a number of residents.
    */
    public double getResidents()
   {
      return residents;
   }
    /**
    * This method is getting service charge per resident.
    * @return serviceChargePerResident is a money of need of service.
    */
    public double getServiceChargePerResident()
   {
      return serviceChargePerResident;
   }
    /**
    * This method is setting owner name.
    * @param ownerName is name of owner
    */
   public void setOwnerName(String ownerName)
   {
      this.ownerName = ownerName;
   }
    /**
    * This method is setting address name.
    * @param address is name of address
    */
   public void setAddress(String address)
   {
      this.address = address;
   }
   /**
    * This method is setting residents.
    * @param residents is number of residents.
    */
   public void setResidents(int residents)
   {
      this.residents = residents;
   }
   /**
    * This method is setting service Charge Per Resident.
    * @param serviceChargePerResident is needinng money for per resident.
    */
   public void setServiceChargePerResident(double serviceChargePerResident)
   {
      this.serviceChargePerResident = serviceChargePerResident;
   }
   /**
    * This method calculating a total service fees.
    * @return result, which is total money.
    */
   public double calculateTotalServiceFee()
   {
      //Variable
      double result;
      //ProgramCode
      result = residents * serviceChargePerResident;
      return result;
   }/**
    * This method shows a knowledge of house.
    * @return result, printing house information.
    */
   public String toString()
   {
      //Variable
      String result;
      //Program Code
      result = "" ;
      result += "Owner: " + ownerName + "\n" + "Address: " + address + "\n" + "residents: " + residents + "\n" + "number of residents montly fee: " + calculateTotalServiceFee() + "\n";
      return result;
   }

  
   
}