/*
 * The program creates a new Site, using name input from the user
 * And then, it including a menu.
 * This menu is for adding house, wiev house and searching house bey fees.
 * @author Muhammed Naci Dalk�ran
 * @date   24.04.2018
 */
import java.util.Scanner;
import java.util.ArrayList;
public class SiteApplication
{
   public static void main ( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      //Variable
      Site site;
      String siteName;
      int choice;
      ArrayList<Hause> houses;
      //ProgramCode
      System.out.print( " please enter a name of site " );
      siteName = scan.next();
      site = new Site( siteName );
      do
      {
         System.out.println( " 1-Add House" );
         System.out.println( " 2-View Houses" );
         System.out.println( " 3-Search Houses by Fee" );
         System.out.println( " 4-Exit " );
         System.out.print( "Enter choice : " );
         choice = scan.nextInt( );
         //Condition
         if( choice == 1 )
         {
            site.addHouse( );
         }
         else if( choice == 2 )
         {
            site.wievHouses( );
         }
         else if( choice == 3 )
         {
            System.out.print( "Enter minimum and maximum fee: " );
            double min = scan.nextDouble( );
            double max = scan.nextDouble( );
            houses = site.searchHouseByFee( min, max );
            System.out.println( "Houses on Site with fee between " + min + " and " + max + " TL: " );
            for(int i = 0; i < houses.size(); i++ )
            {
               System.out.println( houses.get(i) );
            }
         }
         //For invaid value
         else if( choice > 4 )
         {
            System.out.println( "Invalid Choice \n" );
            choice = 0;
         }
      }
      //For exit
      while( choice <= 3 ); 
      System.out.println( "---End of Lab10b---" );
   }
}