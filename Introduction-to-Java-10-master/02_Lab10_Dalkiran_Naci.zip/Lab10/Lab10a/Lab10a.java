/*
 * The program is calculation program.
 * The program �nput from user n,which determines how many number.
 * @author Muhammed Naci Dalk�ran
 * @date   24.04.2018
 */
import java.util.Scanner;
public class Lab10a
{
   public static void main(String[] args)
   {
      Scanner scan = new Scanner(System.in);
      //Constant
      final String LINE = "******************************************************* " ;
      
      //Variable
      String polynomial;
      int n;
      int variable;
      int result;
      int[] coefficent;
      
      //Program Code
      polynomial = "";
      
      //Input from user
      System.out.print( "Please enter the value of N:" );
      n = scan.nextInt( );
      
      //for n + 1 term
      coefficent = new int[n + 1];
      
      //Input coeddients from users
      for(int i = n; 0 <= i; i--)
      {
         System.out.print( "Please enter the value of coefficent a" + i + ":" );
         coefficent[i] = scan.nextInt(); 
      }
      //Input from X user
      System.out.print( "Please enter the X value: " );
      variable = scan.nextInt();
      System.out.println( LINE );
      //unless user �nputs 
      while( !(variable == 0))
      {
         
         result = calculatePolynomial( coefficent, variable, n );
         polynomial = printPolynomial( coefficent, variable, n );
         
         System.out.println( "for x = " + variable );
         
         System.out.println( polynomial + " = " + result );         
         System.out.println( "" );
         System.out.print( "Enter an variable" );
         variable = scan.nextInt( );
      }
      System.out.println( LINE );
      System.out.println( "--- End of Lab10a ---" );
      
   }
   /**
    * This method is calculating a result. 
    * @param coefficent is number of coeffient
    * @param variable is value of X
    * @param n is how many number �nputed by users.
    * @return result is resulting a calculation.
    */
   public static int calculatePolynomial( int[] coefficent, int variable, int n )
   {
      int result;
      result = 0;
      for(int i = 0; i <= n; i++)
      {
         result = (int) (coefficent[i] * Math.pow( variable, i ) + result );
      }
      return result;
   }
   /**
    * This method is calculating a result. 
    * @param coefficent is number of coeffient
    * @param variable is value of X
    * @param n is how many number �nputed by users.
    * @return result is  printing result.
    */
   public static String printPolynomial(int[] coefficent, int variable, int n)
   {
      String result;
      result = "";
      for(int i = 0; i <= n; i++)
      {
         result = coefficent[i] + "(" + variable + "^" + i + ")" + " + " + result;
      }
      result = result.substring(0, result.length() - 8);
      return result;
   }
}