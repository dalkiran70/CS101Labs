/*
 * The class has a a few method including a
 * get, set, toString, constructer.
 * It supply to generate(create) a guitar.
 * And then, it demostrates guitar's brand model and price.
 * @author Muhammed Naci Dalk�ran
 * @date   17.04.2018
 */
public class Guitar
{
   //Proporties
   private String brand;
   private String model;
   private int price;
   /**
    * This method is Constructor method.
    * @param brand is a brand of guitar
    * @param model is a model of guitar.
    * @param price price of guitar.
    */
   public Guitar( String brand, String model, int price )
   {
      this.setBrand( brand );
      this.setModel( model );
      this.setPrice( price );
   }
   /**
    * This method is copy Constructor method.
    * @param newGuitar is creating a new employee
    */
   public Guitar( Guitar newGuitar )
   {
      this.setBrand( newGuitar.getBrand( ) );
      this.setModel( newGuitar.getModel( ) );
      this.setPrice( newGuitar.getPrice( ) );
   }
   /**
    * This method is getting brand name
    * @return getBrand is a name of brand.
    */ 
   public String getBrand( )
   {
      return brand;
   }
   /**
    * This method is getting Model name
    * @return getBrand is a name of model.
    */ 
   public String getModel( )
   {
      return model;
   }
   /**
    * This method is getting price value
    * @return getBrand is a value of price.
    */ 
   public int getPrice()
   {
      return price;
   }
   /**
    * This method is setting brand name
    * @param brand is name of brand
    */
   public void setBrand( String brand )
   {
      this.brand = brand;
   }
   /**
    * This method is setting model name
    * @param model is name of model
    */
   public void setModel(String model)
   {
      this.model = model;
   }
   /**
    * This method is setting price value
    * @param price is value of price.
    */
   public void setPrice( int price )
   {
      this.price = price;
   }
   /**
    * This method show the initial situaiton to user
    * @return result, which is a combination of brand, model, price.
    */
   public String toString( )
   {
      //Variable
      String result;
      
      //Program Code
      result = " ";
      result += brand + ",  " + model + ",  " + price;
      return result; 
   }
}