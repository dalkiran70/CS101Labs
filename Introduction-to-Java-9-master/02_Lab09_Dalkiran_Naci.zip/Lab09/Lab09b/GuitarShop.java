/*
 * The program create a guitars and
 * it generate a menu for guitars.
 * The owner can add new guitar or 
 * remove old guitar or even change price.
 * @author Muhammed Naci Dalk�ran
 * @date   17.04.2018
 */
import java.util.Scanner;
import java.util.ArrayList;
public class GuitarShop
{
   public static void main( String [] args )
   {
      Scanner scan = new Scanner(System.in);
      
      //Constant
      final String L�NE = "***********************************************************";
      
      //Variable
      int choice;
      String brand;
      String model;
      int price;
      int count;
      int idOfGuitar;
      String line;
      ArrayList<Guitar> guitarList;
      
      //Program Code
      count = 0;
      guitarList = new ArrayList<Guitar>( );
      do
      {
         //Input from users
         System.out.println( "Welcome to the guitar Shop. Please enter your choice" );
         System.out.println( "(1) Add Guitar " );
         System.out.println( "(2) Sell Guitar " );
         System.out.println( "(3) Change Price" );
         System.out.println( "(4)Exit " );
         System.out.print( "Choice : " );
         choice = scan.nextInt( );
         System.out.println( L�NE );
         //Condition 1
         //Adding a guitar
         if ( choice == 1 )
         {
            
            System.out.println( "Please enter quitar brand: " );
            brand = scan.next( );
            System.out.println( "Please enter quitar model: " );
            model = scan.next( );
            System.out.println( "Please enter quitar price: " );
            price = scan.nextInt();
            
            //Creating a guitar object
            Guitar firstGuitar = new Guitar( brand , model, price );
            guitarList.add( count, firstGuitar );
            System.out.println( "Current Status of Guitar Shop" );
            System.out.println( " " );
            
            //Printing a list of guitar
            for( int i = 0 ; i < guitarList.size( ); i++ )
            {
               
               System.out.println( i + ":\t " + guitarList.get( i ) );
            } 
            count++;
            System.out.println( " " );
            System.out.println( L�NE );
         }
         
         //Condition 2 
         //Selling guitar
         else if(  choice == 2 )
         {
            if(  guitarList.size( ) > 0 )
            {
               System.out.println( "Current Status of Guitar Shop" );
               System.out.println( " " );
               //Showing a List of guitars
               for( int i = 0; i < guitarList.size(); i++ )
               {
                  System.out.println(  i + ": " + guitarList.get( i ) );
               }
               //Input from users
               System.out.println( "Please enter guitar id that will be deleted:  " );
               idOfGuitar = scan.nextInt();
               //Defining a id of guitar
               for( int i = 0; i < guitarList.size(); i++ )
               {
                  if( idOfGuitar == i )
                  {
                     guitarList.remove(i);
                  }
               }
               //Printing
               System.out.println( "Current Status of Guitar Shop" );
               System.out.println( " " );
               for( int i = 0; i < guitarList.size(); i++ )
               {
                  System.out.println(  i + ": " + guitarList.get( i ) );
               }
               System.out.println( " " );
               System.out.println( L�NE );
            }
            else
            {
               System.out.println( "Guitar Shop is empty" );
               System.out.println( " " );
               System.out.println( L�NE );
            }
         }
         //Condition 3
         //Changing a price of guitar
         else if( choice == 3 )
         {
            if( ( guitarList.size() > 0 ) )
            {
               System.out.println( "Current Status of Guitar Shop" );
               System.out.println( " " );
               for( int i = 0; i < guitarList.size(); i++ )
               {
                  System.out.println(  i + ": " + guitarList.get( i ) );
               }
               System.out.println( " " );
               System.out.println( "Please enter guitar id whose price will be changed" ); 
               int i = scan.nextInt();
               System.out.println( "Please enter new price : " );
               int newPrice = scan.nextInt();
               if( newPrice < 0)
               {
                  System.out.println( "Invalid value for Price !!!" );
               }
               else
               {
                  guitarList.get(i).setPrice( newPrice );
                  System.out.println( "Current Status of Guitar Shop" );
                  System.out.println( " " );
                  for( int a = 0; a < guitarList.size(); a++ )
                  {
                     System.out.println(  a + ": " + guitarList.get( a ) );
                  }
                  System.out.println( " " );
                  System.out.println( L�NE );
               }
            }
            else
            {
               System.out.println( "Guitar Shop is empty" );
               System.out.println( L�NE );
            }
            
         }
         //condition 4
         //Quit program
         else if( choice == 4 )
         {
            System.out.println( " " );
            System.out.println( "End of GuitarShop" );
            System.out.println( L�NE );
         }
      }
      //The program Menu range
      while( choice <= 3 && choice > 0);
      
   }
}