/*
 * The Program including a Array list.
 * This list including random integer between [0, 1000]
 * And the program calculating largest even and Odd number list have.
 * And Printing a this calculation result.
 */
import java.util.ArrayList;
import java.util.Scanner;
public class Lab09a
{
   public static void main( String [] args )
   {
      Scanner scan = new Scanner(System.in);
      
      //Constant
      final int RANGE = 1000;
      final String LINE = "***********************************************************";
      
      //Variable
      int length;
      int largestEven;
      int largestOdd;
      
      //Program code
      //Generating a Array list
      ArrayList<Integer> random = new ArrayList<Integer>();
      
      //Input from user
      System.out.print( "Please a number:" );
      length = scan.nextInt();
      System.out.println( LINE ); 
      largestEven = -1;
      largestOdd = -1;
      
      if( length <= 0 )
      {
         System.out.println( "No number generated ! " );
         System.out.println( LINE ); 
      }
      else
      {
         //Adding random number to Array list
         for(int i = 1; i <= length; i++)
         {
            random.add( ( int )( Math.random() * RANGE ) );
         }
         //Printing a index number and list number.
         for (int i = 0; i< random.size(); i++)
         {
            System.out.println( "Index: " + i + " values: " + random.get(i) );  
         }
         //Calculating a largest odd and largest even.
         for (int i = 0; i< random.size(); i++ )
         {
            if( (random.get(i) % 2) == 0)
            {
               largestEven = Math.max( largestEven, random.get(i) );     
            }
            else 
            {
               largestOdd = Math.max( largestOdd, random.get(i) );
            }
         }
         //Printing a largest odd and largest even
         System.out.println( LINE ); 
         System.out.println( "Greatest of odd numbers in the list: " + largestOdd );
         System.out.println( "Greatest of even numbers in the list: " + largestEven ); 
         
      }
   }
}
