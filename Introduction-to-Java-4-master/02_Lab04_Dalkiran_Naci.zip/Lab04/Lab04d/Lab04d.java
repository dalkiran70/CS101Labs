/*
 * The program computes arctan(x) in radians when using Taylor series.
 * The program inputs from the user the value of x, which should be in the range (-1,1) and
 * also the precision of the summation.
 * The program calculates how many terms of the series are needed to
 * approximate the sum up to the given precision for the given x value.
 * In the program, calculate the sum repeatedly until the absolute value of the term becomes
 * less than or equal to precision
 * And then, at each step, print the approximated value of the sum so
 * that you can see the progression.
 * @author Muhammed Naci Dalk�ran
 * @date   06.03.2018
 */  
import java.util.Scanner;

public class Lab04d
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      
      // Variables
      double unknownValue;
      double precision;
      double tanValue;
      double control;
      int n;
      
      //Program Code
      n = 0;
      
      // Enter unknownvalue from user as double
      System.out.println( "Enter x:" );
      unknownValue = scan.nextDouble(); 
      
      // Enter percision from user as double
      System.out.println( "Enter precision:" );
      precision = scan.nextDouble(); 
      
      System.out.println( "*************************" );
  
      //Check validty
      if( unknownValue > -1 && unknownValue < 1 ) 
      {
         tanValue = 0;
         
         // to make sure the loop will be done at least once
         control = precision + 1;   
         while( precision <= control )
         {
            //Calculating value of tan
            tanValue = ( Math.pow( -1 , n ) ) * ( Math.pow( unknownValue , ( 2 * n ) + 1 ) )/ ( ( 2 * n ) + 1 ) + tanValue; 
            
            //control  precision
            control = Math.abs( ( Math.pow( -1 , n ))*( Math.pow( unknownValue , ( 2 * n ) + 3 ) ) / ( ( 2 * n) + 3 ) ); 
            System.out.println( "Current sum: " + tanValue );
            n++;
         }
         System.out.println( "*************************" );
         System.out.println( "Computed with " + precision + " precision in " + n + " steps." );
         System.out.println( "arctan(" + unknownValue + ") = " + tanValue + " radians." );
      }
      else
      {
         System.out.println("x have to be between (-1,1)");
      }
   }
}