 /*
 * The program asks input,which is one positive integer, from users and 
 * calculates its prime divisors.
 *
 * @author Muhammed Naci Dalk�ran
 * @date   06.03.2018
*/
import java.util.Scanner;

public class Lab04b
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      
      //Variables
      int primeDivisor ;
      int userInput;
      int count;
      
      //The smallest prime divisor
      primeDivisor = 2; 
      
      //Program Code
      //Input from user
      System.out.println( "Please enter an integer: " );
      userInput = scan.nextInt();
      
      System.out.print( "Prime divisors of " + userInput + ": " );
      
      //"1" has not any prime divisor. 
      while( userInput != 1 ) 
      {
         count = 1;
         while( userInput % primeDivisor == 0 )
         {
            userInput = userInput / primeDivisor ;
            //To calculate each prime number once time
            if( count == 1 ) 
            {
               System.out.print( primeDivisor + " " );
            }
            count++;
         }
         primeDivisor++;
      }
   }
}