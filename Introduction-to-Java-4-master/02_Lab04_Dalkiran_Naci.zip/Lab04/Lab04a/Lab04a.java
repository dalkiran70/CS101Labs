 /*
 * The program  calculates the factorial of a given
 * number
 * Firtly, the program asks for an integer number x between 
 * [0 � 13] and calculates its factorial.
 * The program runs until user�s input is an invalid number (outside of interval)
 * @author Muhammed naci dalk�ran
 * @date   06.03.2018
 */
import java.util.Scanner;

public class Lab04a
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      
      //Variables
      int userInput; 
      long factorial;
      int term;
     
      //Program Code
      term = 1;
      factorial = 1;
      
      //Intput from users
      System.out.println( "Please enter a intiger [0-13] " );           
      userInput = scan.nextInt(); 
      
      
      //Check that the number is within the proper range
      while ( userInput <= 13 && userInput >= 0 ) 
      {
         //Calculation 
         while( term <= userInput ) 
         {
            factorial =  factorial  * term ;
            
            term++;
         }
         
         System.out.println( userInput + "!" + " = " + factorial );
         
         factorial = 1;
         term = 1;
         
         System.out.println( "Please enter a intiger [0-13] " ); 
         userInput = scan.nextInt();
      }
      System.out.println( "Goodbye!" );   
   }
}