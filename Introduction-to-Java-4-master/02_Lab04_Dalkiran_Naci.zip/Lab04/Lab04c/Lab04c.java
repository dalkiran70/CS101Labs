 /*
 * The program prompts the user to enter a character, and
 * an int value
 * Also, the program prompts the user to enter width?, and then print out a triangle 
 * formed using ch characters having a height of width characters.
 * @author Muhammed Naci Dalk�ran
 * @date   06.03.2018
 */
import java.util.Scanner;

public class Lab04c
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      
      // Varibles
      char chart;
      int width;
      int lineValue1;
      int widthValueA;
      int widthValueB;
      int lineValue2;
      
      lineValue1 = 1;
     
      lineValue2 = 1;
      
      //Program Code
      // Input from user as char
      System.out.println("Please enter a character:");
      chart = scan.next(".").charAt(0); 
      
      // Input from user as int for determining width
      System.out.println("Please enter a width value as an intiger:");
      width = scan.nextInt(); // Input from user as int
      
      widthValueB = width;
      widthValueA = width;
      
      //Identify a width   
      while( lineValue1 <= width) 
      {
         //This determines how many there are space each line
         while( widthValueB < widthValueA ) 
         {
            System.out.print(" ");
            
            widthValueA--;
         }
         //Determining how many char each line
         while( lineValue2 <= widthValueB ) 
         {
            System.out.print(chart);
            
            lineValue2++;
         }
         
         System.out.println("");
         
         lineValue1++;
         widthValueA = width;
         widthValueB--;
         lineValue2 = 1;
      }
      
   }
}