/*
 * The program prompts the user to enter a character, and
 * an int value
 * Also, the program prompts the user to enter width?, and then print out a triangle 
 * formed using ch characters having a height of width? characters.
 * @author Muhammed Naci Dalk�ran
 * @date   06.03.2018
 */
import java.util.Scanner;

public class Lab04c
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      
      // Varibles
      char chart;
      int width;
      int lineValue1;
      int lineValue2;
      int lineValue3;
      
      
      
      
      //Program Code
      // Input from user as char
      System.out.println( "Please enter a character:" );
      chart = scan.next( "." ).charAt(0); 
      
      // Input from user as int for determining width
      System.out.println( "Please enter a width value as an intiger:" );
      width = scan.nextInt(); 
      
      int k = width;
      while( --k >= 0 ) 
      {
         
          lineValue1 = k;
          lineValue2 = k;
          lineValue3 = k;
         
         while( lineValue1 < width ) 
         {
            lineValue1++;
            System.out.print( chart );
         }
         
         
         while( lineValue2 > 0 ) 
         {
            lineValue2--;
            System.out.print( "  " );
         }
         
         while ( lineValue3 < width )
         {
            lineValue3++;
            System.out.print( chart );
         }
         
         
         
         System.out.println( "" );
         
      }
      
   }
}