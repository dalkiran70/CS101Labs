/*
 * The program asks the user for a word and displays all substring of that wordi sorted by length.
 * @author Muhammed Naci Dalk�ran
 * @date   13.03.2018
 */ 
import java.util.Scanner;
public class Lab05c
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      //Variable
      String input;
      int length;
      
      //Program Code
      //Input from users
      System.out.print( "Enter a word : " );
      input = scan.next();
      //determines lenght of the word
      length = input.length();
      
      System.out.println( "All substrings of funny, sorted by length are : " );
      
      //determines how many letters there are each line
      for( int i = length; i > 0; i-- )
      {
         
         for( int j = 0 ; j <= length - i ; j++ )
         {
            //Cheak point for avoiding eror
            
               //determines printed letter interval
               System.out.println(input.substring( j, i + j ) );
         }
      }   
   }
}