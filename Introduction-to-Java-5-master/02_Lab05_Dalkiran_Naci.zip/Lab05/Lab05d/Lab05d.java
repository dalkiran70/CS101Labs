/*
 *  The program reads an integer n from the users and displays the first n Fibonacci numbers.
 * @author Muhammed Naci Dalk�ran
 * @date   13.03.2018
 */ 

import java.util.Scanner;
public class Lab05d
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      //Variable
      int input;
      int fibonacciNumber1;
      int fibonacciNumber2;
      int temp;
      
      //Program Code
      fibonacciNumber1 = 1;
      fibonacciNumber2 = 1;

      do
      {
         //Input from users
         System.out.print( "Enter a positive integer" );
         input = scan.nextInt(); 
         System.out.println( input + " Fibonacci numbers are : " );
         
         //Determines how many number there are
         for( int i = 0; i < input; )
         {
            //Determines how many lines there are (5 lines)
            for (int j=0; j < 5 &&  i < input; j++, i++ )
            {
               //Each number right aligned
               System.out.printf( "%10d" , fibonacciNumber1 );
               //For avoiding to lose data
               temp= fibonacciNumber2;
               fibonacciNumber2 += fibonacciNumber1;
               fibonacciNumber1 = temp;
            }
            System.out.print( "\n" );
         }
      }
      //For asking every time when input is equal and smaller than 0
      while ( input <= 0 );
   }
}

