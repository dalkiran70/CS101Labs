/*
 * The menu driven program, that asks the user to provide an integer from 1 to 3. 
 * If any number given out of this range, the program ignores that number and  
 * continues to ask numbers 1-3.
 * In the first selection, the program inputs 2 name from users.
 * And the program shows common characters in both name(Case-insensitive)
 * In the second selection, the program inputs value between -1 and 1 from users.
 * Also, the program inputs a precision.
 * And then,It calculates the approximate value of 1 / (1 - x).
 * The program stops calculation whenever the increment is less than given precision value. 
 * @author Muhammed naci dalk�ran
 * @date   13.03.2018
 */ 
import java.util.Scanner;
public class Lab05b_extra
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      //Variable
      int selection;
      String name;
      String anotherName ;
      double input;
      double precision;
      double result;
      int fibonacciNumber1;
      int fibonacciNumber2;
      int temp;
      int count;
      
      
      //Program Code
      //To ask a selection everytime
      fibonacciNumber2 = 1;
      fibonacciNumber1 = 1;
      count = 1;
      do 
      {
         System.out.println( "=== Make your selection ===" );
         System.out.println( "1) Common characters" );
         System.out.println( "2) 1/(1-x) calculation" );
         System.out.println( "3)Fibonacci calculation" );
         System.out.println( "4)Exit" );
         System.out.print( "Your selection : " );
         selection = scan.nextInt();
         
         //The first saelection
         if ( selection == 1 )
         {
            //Iput from users
            System.out.print( "Enter a string : " );
            name = scan.next();
            System.out.print( "Enter another string : " );
            anotherName = scan.next();
            
            //For case-insensitive
            name = name.toLowerCase();
            anotherName = anotherName.toLowerCase();
            
            //For scenning whole first name
            for( int i = 0; i < name.length()-1; i++ )
            {
               for ( int j = i + 1; j < name.length(); j++ )
               {
                  //For avoiding print same common char
                  if( name.charAt(i) == name.charAt(j) )
                  { 
                     name = name.substring(0,j) + name.substring( j+1, name.length() );
                     j--;
                  }
               }
            }
            
            //For scenning whole second name
            for( int i = 0; i < anotherName.length()-1; i++ )
            {
               for ( int j = i + 1; j < anotherName.length(); j++ )
               {
                  //For avoiding print same common char
                  if( anotherName.charAt(i) == anotherName.charAt(j) )
                  { 
                     anotherName = anotherName.substring(0,j) + anotherName.substring( j+1, anotherName.length() );
                     j--;
                  }
               }
            }
            System.out.print( " Common characters : " );
            //After desposing of same letter in each name, comparing names
            for( int i = 0; i < name.length(); i++ )
            {
               for ( int j = 0; j < anotherName.length(); j++ )
                  if( name.charAt(i) == anotherName.charAt(j) )
               {
                  //print common letter
                  System.out.print( name.charAt(i) );
               }
            }
            System.out.print("\n");
         }
         //Second condition
         else if ( selection == 2 )
         {
            //To ask value everytime if the numbers are not on interval (-1,1)
            do
            {
               //Input value from users
               System.out.print( "Enter an x : (-1,1) : " );
               input = scan.nextDouble();
            }
            while( input <= -1 && input >= 1 );
            
            //Input percision value from user
            System.out.print( "Enter precision " );
            precision = scan.nextDouble();
            
            result = 0;
            
            //Calculation
            for ( int i = 0; Math.abs(Math.pow(input,i)) >= precision; i++ )
            { 
               result = result + Math.pow(input,i);
               System.out.println( " Current result is : " + result );
            }
         }
         else if ( selection == 3 )
         {
            do
            {
               //Input from users
               System.out.print( "Enter a positive integer" );
               input = scan.nextInt(); 
               System.out.println( input + " Fibonacci numbers are : " );
               
               //Determines how many number there are
               for( int i = 0; i < input; )
               {
                  //Determines how many lines there are (5 lines)
                  for (int j=0; j < 5 &&  i < input; j++, i++ )
                  {
                     temp= fibonacciNumber2;
                     fibonacciNumber2 += fibonacciNumber1;
                     fibonacciNumber1 = temp;
                     count++;
                     if( count % 2 == 0)
                     {
                        System.out.printf( "%10d" , fibonacciNumber1 );
                     }
                  }
                  System.out.print( "\n" );
               }
            }
            //For asking every time when input is equal and smaller than 0
            while ( input <= 0 );
         }
      }
      //If users input 3, they exit a program.Also, unless users input 1-2-3, the program ask a menu again.
      while( selection != 4 );
      System.out.println( " Goodbye!!!" );
   }
}


