/*
 * The program asks the user for an integer N and a character
 * and prints a shape on the screen using the given character and N.
 * In each line, it prints the given character, from starting line 1 to N, and it  increases.
 * line N has N characters printed, and then it  starts to decrease 
 * one by one as it goes below.
 *
 * @author Muhammed naci dalk�ran
 * @date   13.03.2018
 */ 
import java.util.Scanner;
public class Lab05a
{
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      //Variable
      char ch;
      int width; 
      
      //Program Code     
      //Input from user as chart
      System.out.print( "Please! Enter a character: "); 
      ch = scan.next(".").charAt(0);
      
      //Input from user as width
      System.out.print( " Please! Enter a width: ");
      width = scan.nextInt();
      
      //Determine how many char the longest line have     
      for( int i = 0; i < width; i++)
      { 
         //Print char 
         for ( int b = 0; b <= i; b++)
         {
            System.out.print(ch);
         }
         System.out.print("\n");
      }
      //Determinate that after printed char, how many lines there are
      for( int i = width - 1; i >= 0; i--)
      {
         //print char
         for ( int b = 0; b < i ; b++)
         {
            System.out.print(ch);
         }
         System.out.print("\n");
      }
   }
}




