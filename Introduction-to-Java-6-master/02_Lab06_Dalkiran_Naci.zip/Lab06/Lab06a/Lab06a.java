 /*
 * The Program that computes the volume of one slice of a birthday cake.
 * The program inputs radious and height of cake.
 * Then, program inputs number of people from users.
 * @author Muhammed Naci Dalk�ran
 * @date   27.03.2018
*/
import java.util.Scanner;
public class Lab06a  
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
    
    //Variable
    int radius;
    int height;
    int numberOfPeople;
    double volumeOfCake;
    
    //Program Code
    //Input from users
    System.out.println("Enter radius of the cake: ");
    radius = scan.nextInt();
    System.out.println("Enter height of the cake: ");
    height = scan.nextInt();
    System.out.println("Enter number of people: ");
    numberOfPeople = scan.nextInt();
    
    // for asking number of people ever time
    while(numberOfPeople != 0 )
    {
      volumeOfCake = volumeCalculator(radius, height, numberOfPeople );   
      
      System.out.println("Number of people is: " + numberOfPeople);
      System.out.println("Volume of a slice is: " + volumeOfCake);
      
      System.out.println("*****************************************");
      
      System.out.println("Enter number of people: ");
      numberOfPeople = scan.nextInt();
    }
    //if number of people is 0, the program exits
    System.out.println("Goodbye!");
  }
   /**
    * This method calculates volume of cake
    * @param radius integer that is inputed from user
    * @param height integer that is inputed from user
    * @param numberOfPeople integer that is inputed from user
    * @return number of "bc" in line of the text
    */
  
  public static double volumeCalculator(int radius,int height, int numberOfPeople )
  {
    double volume;
    
    volume = ( Math.PI * height * Math.pow(radius, 2)) / numberOfPeople;
    
    return volume;
  }
}