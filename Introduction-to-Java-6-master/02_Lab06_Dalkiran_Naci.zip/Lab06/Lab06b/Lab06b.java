/*
 * The prgoram computes and outputs the number of substring "bc"s.
 * It splits the string from the first occurrence of "bc". 
 * @author Muhammed Naci Dalk�ran
 * @date   27.03.2018
 */
import java.util.Scanner;
public class Lab06b
{
   
   private static String SUB_SEQUENCE = "bc";
   
   public static void main( String[] args )
   {
      Scanner scan = new Scanner( System.in );
      //Variable
      String input;
      String beforeBorder;
      String afterBorder;
      int number;
      int cheak;
      
      //Program Code
      //Input from users
      System.out.println( "Enter a sequence " );
      input = scan.nextLine();
      
      //Control Later only "a", "b", "c", "d"
      cheak = 0;
      for( int i = 0; i <= input.length() - 1; i ++)
      {
         
         if ( input.charAt( i ) == 'a' || input.charAt(  i) == 'b' || input.charAt( i ) == 'c' || input.charAt( i ) == 'd' )
         {
            cheak ++;
         }
         
      }
      if ( cheak == input.length() )
      {
         //Input from users
         number = numberOfBorder( input );
         if (number > 0)
         {    
            System.out.println( "The number of \"bc\"s int the sequence : " + number );
            
            
            beforeBorder = input.substring( 0 , firstBorder (input) );
            if ((firstBorder (input) + 2) == input.length())
               afterBorder = input.substring(firstBorder(input));
            else
            {
            afterBorder = input.substring( firstBorder (input) + 2, input.length() );
            }
            System.out.println("First part: " + beforeBorder);
            System.out.println("Second part: " + afterBorder);
            
         }
         else 
         {
            System.out.println( "There is no \"bc\" . " );
         }
         
      }
      else 
      {
         System.out.println( "Input has to include only a,b,c,d" );
      }
   }
   
   /**
    * This method calcutes number of "bc" in line of the text.
    * @param input a string inputed from user
    * @return number of "bc" in line of the text
    */
   
   public static int numberOfBorder( String input)
   {
      int count;
      count = 0;
      for(int i = 0 ; i < input.length()  ; i++)
      {
         for(int j = input.length()  ; i < j ; j--)
         {
            if( input.substring(i,j).equals( SUB_SEQUENCE ))
            {
               count++;
            }
         }
      }
      return count;
   }
   
   /**
    * This meyhod defines border that is after and before "bc".
    * @param input a string inputed from user
    * @return is a border that separeting line text two part
    */
   public static int firstBorder ( String input)
   {
      //Variable
      int count;
      int border;
      
      //Program Code
      border = 0;
      count = 0;
      for(int i = 0 ; i < input.length() ; i++ )
      {
         for( int j = input.length() ; i < j ; j-- )
         {
            if( ( input.substring( i, j ).equals( SUB_SEQUENCE ) ) && ( count == 0 ) )
            {
               border = i;
               count++;
            }
         }
      }
      return border;
   }
}