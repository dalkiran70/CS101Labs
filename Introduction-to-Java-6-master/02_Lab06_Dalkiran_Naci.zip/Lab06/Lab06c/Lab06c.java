/*
 * The program that simulates a die rolling game.
 * The program inputs the total money  and prediction and bet money from the user.
 * The program ask each time bet money and prediction.
 * @author Muhammed Naci Dalk�ran
 * @date   27.03.2018
 */
import java.util.Scanner;
public class Lab06c
{
   public static void main(String[] args)
   {
      Scanner scan = new Scanner(System.in);
      //Variable
      double totalMoney;
      double bet;
      int prediction;
      int diceValue;
      
      //Program Code
      System.out.println("Enter total money: ");
      totalMoney = scan.nextDouble();
      
      //For calculating every time
      do
      {
         // Input from user
         System.out.println("Enter the amount of money you want to bet: ");
         bet = scan.nextDouble();
         
         if ( bet <= totalMoney)
         {
            System.out.println("Enter your prediction( 1 for ODD, 2 for EVEN): ");
            prediction = scan.nextInt();
            if ( prediction == 1 || prediction == 2 )
            {
               
               diceValue = diceRoller();         
               totalMoney = money(prediction, bet, totalMoney, diceValue);
               System.out.println("The value of dice is " + diceValue );
               System.out.println("Your total money is: " + totalMoney);
               
            }
         }
         else
         {
            System.out.println( " Bet must be smaller or equal than total money " );
         }
   
   }
   
   //If totaMoney is smaller or equel than 0 and prediction is equal to 1 or 2, the program exits
   while( totalMoney > 0  ); 
   
   System.out.println("Goodbye!");
   
   
}
/**
 * This method determines odd or even die value
 * @param dicevalue is die value
 * @return number that identify odd or even
 */

public static int evenOrOdd(int diceValue)
{
   if( diceValue % 2 == 0)
   {
      return 2;
   }
   else
   {
      return 1;
   }
}
/**
 * This method rolls the die
 * @param 
 * @return the value of dice
 */

public static int diceRoller()
{
   int diceValue;
   
   diceValue = (int)(Math.random() * 6) + 1 ;
   
   return diceValue;
}
/**
 * This method calculates total money.
 * @param prediction inputed fro users
 * @param bet inputed from user
 * @param totalMoney inputed from user
 * @param diceValue returned other method
 * @return totalMoney
 */
public static double money(int prediction, double bet, double totalMoney, int diceValue)
{ 
   if ( prediction == evenOrOdd(diceValue))
   {
      totalMoney = totalMoney + (bet / 2);
   }
   else
   {
      totalMoney = totalMoney - bet;
   }
   
   return totalMoney;
}
}