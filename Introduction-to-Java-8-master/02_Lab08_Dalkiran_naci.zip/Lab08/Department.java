/*
 * This Department stores departmanet name and department code.
 * And, it controls department names and department Code
 * @author Muhammed Naci Dalk�ran
 * @date   10.04.2018
 */
public class Department
{
   //Proporties
   private String deptName;
   private String deptCode;
   
   
   /**
    * This method is Constructor method.
    * @param deptName a name of department
    * @param deptCode a code of department
    */
   public Department(String deptName, String deptCode)
   {
      this.setDeptName( deptName );
      this.setDeptCode( deptCode );
   }
   /**
    * This method is getting department Name
    * @return name of department
    */ 
   public String getDeptName()
   {
      return deptName;
   }
   /**
    * This method is getting department Code
    * @return Code of department
    */ 
   public String getDeptCode()
   {
      return deptCode;
   }
   /**
    * This method is setting department Name
    * @param deptName a name, which is department Name
    */
   public void setDeptName(String deptName)
   {
      this.deptName = deptName;
   }
   /**
    * This method is setting Department Code
    * @param deptCode a name, which is Department Code
    */
   public void setDeptCode( String deptCode )
   {
      this.deptCode = deptCode;
   }
   /**
    * This method caompare departments
    * @param target is a department, which is for comparing
    * @return is a boolean, true or false
    */
   
   public boolean equals(Department target)
   {
      //Program Code
      if( (deptName.equals( target.getDeptName () ) ) && ( deptCode.equals( target.getDeptCode() ) ) )
      {
         return true;
      }
      else
      {
         return false;
      }
   }
   
   /**
    * This method show department name and department code
    * @return a string, this demostrates a department Name and Code 
    */
   public String toString()
   { 
      //Variable
      String result;
      //Progrom code
      result = " ";
      result += "DeptName: " + deptName + " Dept Code: " + deptCode ;
      return result;                  
   }   
}