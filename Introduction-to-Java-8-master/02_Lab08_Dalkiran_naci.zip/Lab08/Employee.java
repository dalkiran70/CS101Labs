/*
 * This Employee stores employee name, daily rate, project and department.
 * This Employee is calculating a yearly salary
 * and print a employee proporties.
 * @author Muhammed Naci Dalk�ran
 * @date   10.04.2018
 */
public class Employee
{
   //Constant
   //There are 261 working days per year.
   private final int WORKING_DAYS = 261;
   
   //Proporties
   private String employeeName;
   private double dailyRate;
   private Project project;
   private Department department;
   /**
    * This method is Constructor method.
    * @param employeeName a name of employee
    * @param dailyRate is a number of daily rate
    * @param project is a project
    * @param deptName name of department
    * @param deptCode code of department
    */
   public Employee(String employeeName, double dailyRate, Project project, String deptName, String deptCode )
   {
      this.setDepartment( new Department( deptName, deptCode));
      this.setEmployeeName(employeeName);
      this.setDepartment(department);
      this.setDailyRate(dailyRate);
      this.setProject(project);
   }
   /**
    * This method is copy Constructor method.
    * @param newEmployee is creating a new employee
    */
   public Employee(Employee newEmployee)
   {
      this.setEmployeeName(newEmployee.getEmployeeName());
      this.setDepartment(newEmployee.getDepartment());
      this.setDailyRate( newEmployee.getDailyRate());
      this.setProject(newEmployee.getProject());
   }
   /**
    * This method is getting employee name
    * @return employeeName is a name of employee
    */ 
   public String getEmployeeName()
   {
      return employeeName;
   }
   /**
    * This method is getting department
    * @return department is a department
    */
   public Department getDepartment()
   {
      return department;
   }
   /**
    * This method is getting daily rate
    * @return dailyRate is a  daily rate
    */
   public double getDailyRate()
   {
      return dailyRate;
   }
   /**
    * This method is getting project
    * @return project is project
    */
   public Project getProject()
   {
      return project;
   }
   /**
    * This method is setting Employee name
    * @param employeeName is name of employee
    */
   public void setEmployeeName(String employeeName)
   {
      this.employeeName = employeeName;
   }
   /**
    * This method is setting Employee name
    * @param dailyRate is name of employee
    */
   public void setDailyRate(double dailyRate)
   {
      this.dailyRate = dailyRate;
   }
   /**
    * This method is setting department
    * @param department is department
    */
   public void setDepartment(Department department)
   {
      this.department = department;
   }
   /**
    * This method is setting project
    * @param project is a project
    */
   public void setProject(Project project)
   {
      this.project = project;
   }
  /**
    * This method is calculating yearly salary
    * return result of calculation
    */
   public double calculateYearlySalary()
   {
      return WORKING_DAYS * dailyRate;
   }
   /**
    * This method show the initial situaiton to user
    * @return result, which is a combination of employee name, 
    * calculation, department and project
    */
   public String toString()
   {
      String result;
      result = "";
      result += "Employee name : " + employeeName + " yearly salary : " + this.calculateYearlySalary() + "\n" + department + project;
      return result;  
   }
   
   
}