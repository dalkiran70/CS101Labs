/*
 * This department test is testing that department is the some or not.
 * @author Muhammed Naci Dalk�ran
 * @date   10.04.2018
 */
public class DepartmentTest
{
   public static void main( String [] args )
   {
      //Variables
      Department first, second, third, fourth,fifeth,sixth;
      
      //Program Code
      //Creating department
      first = new Department ( "naci", "IT" );
      second = new Department ( "Mehmet", "PP" );

      third = new Department( "naci", "IT" );
      fourth = new Department( "naci", "IT" );
      
      fifeth = new Department ( "Ali", "GG" );
      sixth =  fifeth;
      
      //Showing screen
      System.out.println( first.equals( second ) );
      System.out.println ( first == second );
      System.out.println( " " );
      System.out.println( third.equals( fourth ) );
      System.out.println ( third == fourth);
      System.out.println( " " );
      System.out.println( fifeth.equals( sixth ) );
      System.out.println ( fifeth == sixth );
      
      
   }
}