/*
 * This Project include methods in order to describe a object.
 * There are  constants value, static data and proporties.
 * This describes cost of Project 
 * in order to calculate cost, it utilize person number,
 * rate per hour, project weeks.
 * And, then it compares project according to cost.
 * @author Muhammed Naci Dalk�ran
 * @date   03.04.2018
 */
public class Project 
{
   //Constant
   private final double TAX = 17.0 / 100.0;
   private final int OVERHEAD = 50000;
   private final int EMP_HOURS_WEEK = 40;
   
   //Static data members
   private static int projectCounter = 1000;
   
   //proporties
   private String projectId;
   private String projectName;
   private char projectType;
   private int personHours;
   private double ratePerHour;
   private int projectWeeks;
   
   /**
    * This method is constructor method
    * @param projectName a name of project
    * @param personHours an hours for each person
    * @param ratePerHour a ration of per Hour
    * @param projectWeeks time of project
    */  
   public Project( String projectName, int personHours, double ratePerHour, int projectWeeks )
   {
      this.projectName = projectName;
      setPersonHours(personHours);
      setRatePerHour(ratePerHour);
      setProjectWeeks(projectWeeks);
      setProjectId();
      setProjectType();
      projectCounter ++;
      
   }
   
   /**
    * This method is getting project ID
    * @return a project Id code
    */ 
   public String getProjectId()
   {
      return "2018 - " + projectId;
      
   }
   /**
    * This method is getting project name
    * @return a project name
    */ 
   public String getProjectName()
   {
      return projectName;
   }
   /**
    * This method is getting project Type
    * @return a project type
    */
   public char getProjectType()
   {
      return projectType;
   }
   /**
    * This method is getting project Type
    * @return a project type
    */
   public int getPersonHours()
   {
      return personHours;
   }
   /**
    * This method is getting ration of per hour
    * @return a proportion of per hour
    */
   public double getRatePerHour()
   {
      return ratePerHour;
   }
   /**
    * This method is getting how many weeks project continues
    * @return a proportion of per hour
    */
   public int getProjectWeeks()
   {
      return projectWeeks;
   }
   /**
    * This method is setting project name
    * @param projectName a name, which is project name
    */
   public void  setProjectName(String projectName)
   {
      this.projectName = projectName;
   }
   /**
    * This method is setting  Hours of each person
    * @param personHours time, which determines a person hours
    */
   public void setPersonHours( int personHours)
   {
      if ( personHours > 0 )
      {
         this.personHours = personHours;
      }
      else 
      {
         this.personHours = 0;
      }
   }
   /**
    * This method is setting  rate of per hour
    * @param ratePerHour time, which determines rate per hour
    */
   public void setRatePerHour( double ratePerHour)
   {
      //Program Code
      if ( ratePerHour > 0 )
      {
         this.ratePerHour = ratePerHour;
      }
      else 
      {
         this.ratePerHour = 0;
      }
   } 
   /**
    * This method is setting  how much time project is continueing
    * @param projectWeeks time, which determines total project weeks
    */
   public void setProjectWeeks( int projectWeeks )
   {
      if ( projectWeeks > 0 )
      {
         this.projectWeeks = projectWeeks;
      }
      else 
      {
         this.projectWeeks = 0;
      }
      
   }
   /**
    * This method is setting  Project ID 
    * @return a code of project
    */
   private void setProjectId()
   {
      this.projectId = "2018 - " + projectCounter;
   }
   /**
    * This method is setting  Project type based on project cost
    */
   public void setProjectType()
   {
      if( calculateProjectCost() > 500000)
      {
         this.projectType = 'm';
      }
      else if( calculateProjectCost() > 100000)
      {
         this.projectType = 'a';
      }
      else if( calculateProjectCost() > 0 )
      {
         this.projectType = 's'; 
      }
      else 
      {
         this.projectType = 'i';
      }
   } 
   /**
    * This method is deactive Project
    */
   public void deactivateProject()
   {
      projectType = 'i' ;
   }
   /**
    * This method is calculating a Project cost
    * @return resource cost
    */
   public double calculateProjectCost()
   {
      //Variable
      double resourceCost;
      
      //Program Code
      resourceCost = personHours * ratePerHour;
      
      //Conditions
      if(resourceCost < 20000 )
      {
         resourceCost += resourceCost * TAX;
      }
      else
      {
         resourceCost = (resourceCost + OVERHEAD) * TAX +( OVERHEAD + resourceCost ) ; 
      }
      return resourceCost;
   }
   /**
    * This method is calculating calculating person resources
    * @return per person resources
    */
   public int calculatePersonResources()
   {
      //Variable
      double result;
      //Program Code
      result = personHours * projectWeeks / projectWeeks;
      //Check
      if ( (result % 1 ) == 0)
      {
         return (int) result;
      }
      return (int) result + 1;
   }
   /**
    * This method is comparing Projects
    * @param project a
    * @return comparing result
    */
   public int compareProjects(Project project)
   {
      //Program Code
      //Conditions
      if ( project.calculateProjectCost() > this.calculateProjectCost() )
      {
         return -1;
      }
      
      else if( project.calculateProjectCost() < this.calculateProjectCost() )
      {
         return 1;
      }
      else 
      {
         return 0;
      }
   }
   /**
    * This method show the initial situaiton to user
    * @return comparing result
    */
   public String toString()
   { 
      //Variable
      String result;
      //Program Code
      result = "";
      if( projectType == 'i')
      {
         result += "-------INACTIVE PROJECT -------\n";
         
         result += "Project Name:"+ projectName;
         result += "\nProject ID: " + projectId;
      }
      else
      {
         result += "Project Name:"+ projectName;
         result += "\nProject ID: " + projectId;
         result += "\nProject Type: " +  projectType;
         result += "\nTeam Size: " + calculatePersonResources();
         result += "\nEstimated Project Cost: " + calculateProjectCost(); 
         result += "\n";
      }
      return result;
   }
   
   
   
}



