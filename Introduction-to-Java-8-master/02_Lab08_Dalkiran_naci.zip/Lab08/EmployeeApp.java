/*
 * This class is a main class.
 * In this class, employees are created.
 * These employees are comparing
 * @author Muhammed Naci Dalk�ran
 * @date   10.04.2018
 */
public class EmployeeApp
{
   public static void main( String[] args)
   {
      //Variable
      Employee naci, ali, veli, copy;
      int count;
      Project firstProject;
      
      //Program Code
      firstProject = new Project( "SunMarkets", 150, 2000, 300);
      naci = new Employee( "Karakus, Zana", 30, firstProject, "Information Technology", "IT"); 
      ali = new Employee( "Racca, Denis", 10, firstProject, "Human Resources", "HR"); 
      veli = new Employee( "Anders, Jamie", 20, firstProject, "Human Resources", "HR"); 
      copy = new Employee(naci);
      System.out.println( " Employees: ");
      System.out.println(naci);
      System.out.println(ali);
      System.out.println(veli);
      System.out.println(copy);
      System.out.println( "--------- end employee list ----------" );
      
      //Conditions( Comparing employees' Department name and Code
      count = 0;
      if(naci.getDepartment().equals(ali.getDepartment()))
      {
         count++;
         System.out.println( "Employees with Matching Departments (" + count + ") " );
         System.out.println( " " );
         System.out.println(naci);
         System.out.println(ali);
      }  
      if(naci.getDepartment().equals(veli.getDepartment()))
      {
         count++;
         System.out.println("Employees with Matching Departments (" + count + ") " );
         System.out.println( " " );
         System.out.println(naci);
         System.out.println(ali);
      }   
      if(ali.getDepartment().equals(veli.getDepartment()))
      {
         count++;
         System.out.println("Employees with Matching Departments (" + count + ") " );
         System.out.println( " " );
         System.out.println(naci);
         System.out.println(ali);
      }   
      if(copy.getDepartment().equals(veli.getDepartment()))
      {
         count++;
         System.out.println("Employees with Matching Departments (" + count + ") " );
         System.out.println( " " );
         System.out.println(naci);
         System.out.println(ali);
      }   
      if(copy.getDepartment().equals(ali.getDepartment()))
      {
         count++;
         System.out.println("Employees with Matching Departments (" + count + ") " );
         System.out.println( " " );
         System.out.println(naci);
         System.out.println(ali);
      }   
      if(copy.getDepartment().equals(naci.getDepartment()))
      {
         count++;
         System.out.println("Employees with Matching Departments (" + count + ") " );
         System.out.println( " " );
         System.out.println(naci);
         System.out.println(ali);
      }   
      
      
      
   }
}