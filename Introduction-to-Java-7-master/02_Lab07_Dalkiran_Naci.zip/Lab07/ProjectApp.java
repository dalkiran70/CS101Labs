/*
 * This programe creates a three projects.
 * And the program compares these three project 
 * based on cost
 * @author Muhammed Naci Dalk�ran
 * @date   03.04.2018
 */
public class ProjectApp
{
   public static void main(String [] args)
   {
      //Varibale
      Project a = new Project( "ArcTech Business Solution", 10, 200, 50000 );
      Project b = new Project( "SunMarkets POS Implementation", 40, 10, 7000 );
      Project c = new Project( "HealthTech Hospital ", 100, 2000, 30000 );
      Project temp = new Project( " ", 0, 0, 0);
      //program Code
      System.out.println(c);
      System.out.println(b);
      a.deactivateProject();
      System.out.println(a);
      System.out.println( "" );
      System.out.println( "Project with greater cost: " );
      
      
      //Comparing Projects
      if(a.compareProjects(b) == -1 )
      {
         temp = a;
         a = b;
         b = temp;
      }
      if(a.compareProjects(c) == -1)
      {
         temp = a;
         a = c;
         c = temp;
      }
      if(b.compareProjects(c) == -1)
      {
         temp = b;
         b = c;
         c = temp;
      }
      System.out.println(a);
   }
}